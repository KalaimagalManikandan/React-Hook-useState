import React from "react";
import "./App.css";
import HooksPrevState from "./component/HooksPrevState";

function App() {
  return (
    <div className="App">
      <HooksPrevState />
    </div>
  );
}

export default App;
