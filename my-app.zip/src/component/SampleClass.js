import React, { Component } from "react";

export class SampleClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: "",
    };
    this.handleChange = this.handleChange.bind(this);
  }
  handleChange(event) {
    this.setState({ firstName: event.target.value });
  }
  render() {
    return (
      <div>
        <h1>Simple Class Component</h1>
        <input
          type="text"
          name="firstName"
          value={this.state.firstName}
          onChange={this.handleChange}
        />
        <p>First Name : {this.state.firstName}</p>
      </div>
    );
  }
}

export default SampleClass;
