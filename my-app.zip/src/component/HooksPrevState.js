import React, { useState } from "react";

function HooksPrevState() {
  const [count, setCount] = useState(0);
  const Increment = () => {
    setCount((prevState) => prevState + 1);
  };
  const IncrementFive = () => {
    for (let i = 0; i < 5; i++) {
      setCount((prevState) => prevState + 1);
    }
  };
  return (
    <div>
      <h1>PrevState in useState</h1>
      <p>Count : {count}</p>
      <button onClick={Increment}>Increment</button>
      <button onClick={IncrementFive}>Increment Five</button>
    </div>
  );
}

export default HooksPrevState;
