import React, { useState } from "react";

function SampleFunction() {
  const [firstName, setFirstName] = useState();
  return (
    <div>
      <h1>Functional Component</h1>
      <input
        type="text"
        name="firstName"
        value={firstName}
        onChange={(event) => {
          setFirstName(event.target.value);
        }}
      />
      <p>First Name : {firstName}</p>
    </div>
  );
}

export default SampleFunction;
