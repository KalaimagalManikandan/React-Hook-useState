import React, { useState } from "react";

function HooksArray() {
  const [items, setItems] = useState([]);
  const [product, setProduct] = useState("");
  const handleProductChange = (event) => {
    setProduct(event.target.value);
  };
  const handleAddProduct = () => {
    product &&
      setItems([
        ...items,
        {
          id: items.length,
          name: product,
        },
      ]);
  };
  return (
    <div>
      <h1>Array in useState</h1>
      <input
        type="text"
        name="product"
        value={product}
        onChange={handleProductChange}
      />
      <button onClick={handleAddProduct}>Add Product</button>

      <ul>
        {items.map((item) => (
          <li key={item.id}>{item.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default HooksArray;
