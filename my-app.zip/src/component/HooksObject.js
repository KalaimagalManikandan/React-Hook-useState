import React, { useState } from "react";

function HooksObject() {
  const [state, setState] = useState({ firstName: "", lastName: "" });

  const handleChange = (event) => {
    setState({ ...state, [event.target.name]: event.target.value });
  };
  return (
    <div>
      <h1>Functional Component</h1>
      <input
        type="text"
        name="firstName"
        value={state.firstName}
        onChange={handleChange}
      />
      <input
        type="text"
        name="lastName"
        value={state.lastName}
        onChange={handleChange}
      />
      <p>First Name : {state.firstName}</p>
      <p>Last Name : {state.lastName}</p>
    </div>
  );
}

export default HooksObject;
